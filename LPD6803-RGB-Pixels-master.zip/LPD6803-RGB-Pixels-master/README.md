LPD6803 Library
===============
tbd